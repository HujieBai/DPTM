
#'
#'  A simulation data used for examples
#'
#' @format A simulation data used for examples
#' \describe{
#' None
#'
#' }
"data"



