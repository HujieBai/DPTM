# DPTM

Dynamic Panel Multiple Threshold Model with Fixed Effects.

`DPTM` estimates fixed-effects dynamic panel linear models and dynamic panel
threshold models by maximum-likelihood type estimators. Unknown thresholds can
be searched either by MCMC, the default, or by a deterministic grid search.

## Main Functions

- `DPML()` fits the linear dynamic panel model with fixed effects.
- `DPTS()` fits single- or multiple-threshold dynamic panel models.
- `Threshold_Test()` runs bootstrap tests for the number of thresholds.

## Threshold Search

By default, `DPTS()` uses the BayesianTools MCMC search:

```r
model_mcmc <- DPTS(
  y ~ x, y ~ z,
  data = d1,
  index = c("id", "year"),
  q = d1$q,
  Th = 1,
  iterations = 1000
)
```

For a deterministic search, set `grid_search = TRUE`. The `grids` argument is
the number of grid points per threshold dimension; the default is 100.

```r
model_grid <- DPTS(
  y ~ x, y ~ z,
  data = d1,
  index = c("id", "year"),
  q = d1$q,
  Th = 1,
  grid_search = TRUE,
  grids = 100
)
```

For multiple thresholds, choose how the grid is searched with
`grid_search_type`:

- `"jointly"` searches the full Cartesian grid. With `Th = 2` and `grids = 100`,
  this evaluates `100 * 100` threshold pairs.
- `"sequential"` adds thresholds one at a time. With `Th = 2` and `grids = 100`,
  this evaluates about `200` candidates in total.

After the initial grid search, `grid_search_iter` controls coordinate-refinement
cycles. The default is `1`. With two thresholds, one cycle re-estimates the first
threshold conditional on the second, then re-estimates the second conditional on
the first, and sorts the final thresholds. Set `grid_search_iter = 0` to skip this
refinement.

```r
model_joint <- DPTS(
  y ~ x, y ~ z,
  data = d1,
  index = c("id", "year"),
  q = d1$q,
  Th = 2,
  grid_search = TRUE,
  grids = 100,
  grid_search_type = "jointly",
  grid_search_iter = 1
)

model_seq <- DPTS(
  y ~ x, y ~ z,
  data = d1,
  index = c("id", "year"),
  q = d1$q,
  Th = 2,
  grid_search = TRUE,
  grids = 100,
  grid_search_type = "sequential",
  grid_search_iter = 1
)
```

The same interface is available in `Threshold_Test()`:

```r
test_grid <- Threshold_Test(
  y ~ x, y ~ z,
  data = d1,
  index = c("id", "year"),
  q = d1$q,
  Th = 1,
  bt = 50,
  grid_search = TRUE,
  grids = 100,
  grid_search_type = "sequential",
  grid_search_iter = 1
)
```

## Installation

```r
devtools::install_github("HujieBai/DPTM")
```

Local source packages can also be installed with:

```r
install.packages("DPTM_x.x.x.tar.gz", repos = NULL, type = "source")
```
