# DPTM 3.0.2

# DPTM 3.0.0

* Rewrote the entire package in OOP (R6 class).
* Detailed instructions and examples have been added to make it more user-friendly.
* The formula interface of R language is exploited, which is more standardized and easy to use.

# DPTM 2.0.0
