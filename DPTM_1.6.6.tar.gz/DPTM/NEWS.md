# DPTM 1.6.0

# DPTM 1.5.2
* Replace pt() by pnorm().
* Add more details in printing of estimate.

# DPTM 1.5.0
* Correct the estimate of standard errors.

# DPTM 1.3.8

# DPTM 1.3.7
* CRAN resubmission.

# DPTM 1.3.6

# DPTM 1.3.5
* CRAN resubmission.

# DPTM 1.2.3

# DPTM 1.1.7

* Initial CRAN submission.
* Supply the linear dynamic panel fixed effects model.
* Supply the dynamic panel multiple thresholds model.
* Supply the test for the number of thresholds.

